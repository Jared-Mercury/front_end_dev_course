$("#btn_1").click(function() {
    $("p").last().prependTo($("p").first());
});

$("#btn_2").click(function() {
    $("p").first().appendTo($("p").last());
});