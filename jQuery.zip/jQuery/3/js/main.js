let sum = 0;

$("#count-sum").click(function() {
    $(".salary").map(function() {
        sum += Number(this.text);
        console.log(sum);
    });

});